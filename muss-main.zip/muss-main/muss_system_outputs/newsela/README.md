Please ask the author (louismartincs@gmail.com) for output on the Newsela dataset, after requestion access [here](https://newsela.com/data).
